print("mbakjago")
